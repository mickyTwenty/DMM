okLARGE_FONT = ("Helvetica", 12)
from tkinter import *
import tkinter
import json
from tkinter import font
import time
import RS232Serial
import re
from barcode.writer import ImageWriter
import barcode
from PIL import Image, ImageTk
import numpy as np
import threading
import tkinter as tk
import sqlite3
from sqlite3 import Error
from datetime import datetime
import decimal
import os
import pathlib
from tkinter import messagebox
import DesignConfig
from subprocess import check_output
import subprocess
from glob import glob
from wireless import Wireless
from tkinter import filedialog
import EmailSetup
import IRScanner
import GenCSVDeleteData
import GenCSVKeepData

global running, trunning, wrunning, wifipath,oldwifipath, irrunning, hostnameedit
running = True
trunning = True
wrunning = True
irrunning = True
hostnameedit = False
dc = DesignConfig.DesignConfig()
global combinedWeight, combinedBarCode, singleBarCode, oldBarCode, activeTruckID
wireless = Wireless()
oldwifipath = None
wifipath = "./img/wifi.png"
BACKGROUNDCOLCODE = '#d6d6c2'
combinedWeight = None
combinedBarCode = None
singleBarCode = None
oldBarCode = None
activeTruckID = None


# Skeleton of the APP
## *********************************************************************************************************************

class MainAppWindow(tk.Tk):

    def __init__(self, *args, **kwargs):
        tk.Tk.__init__(self, *args, **kwargs)
        self.wm_title("DMM V 1.1")
        self.geometry("800x480")
        self.resizable(0, 0)

        # self.overrideredirect(True)
        self.attributes("-fullscreen", True)
        self.bind('<Escape>', lambda e: self.on_closing2())
        # self.wm_attributes('-transparentcolor',self['bg'])

        container = tk.Frame(self, width=500, height=500, background="bisque")

        container.pack(side="top", fill="both", expand=True)

        container.grid_rowconfigure(0, weight=1)
        container.grid_columnconfigure(0, weight=1)

        self.frames = {}

        for F in (MenuPage, SingleLoadPage, CombinedLoadPage, ResultsLoadPage, SetupLoadPage):
            frame = F(container, self)
            self.frames[F] = frame

            frame.grid(row=0, column=0, sticky="nsew")

        self.show_frame(MenuPage)
        self.protocol("WM_DELETE_WINDOW", self.on_closing)

        global wifipath
        try:
            if (wireless.current() is not None):
                wifipath = './img/wifi-online.png'
            else:
                wifipath = './img/wifi.png'
            # print(wifipath)
        except:
            print('Wifi Status checking failed')

    def show_frame(self, cont):
        global running
        running = False
        if cont == SingleLoadPage:
            frame = self.frames[cont]
            frame.initComm()
        # print(cont)
        elif cont == CombinedLoadPage:
            frame = self.frames[cont]
            frame.resetItems()
        else:
            frame = self.frames[cont]
        frame.tkraise()

    def on_closing(self):
        global running, trunning, wrunning, irrunning
        print('Closing...')
        running = False
        trunning = False
        wrunning = False
        irrunning = False
        CloseMessageWindow("Quit Application", "Released Resources!!! You may close now...")
        print('Closing...')
        print('END')

    def on_closing2(self):
        global running, trunning, wrunning, irrunning
        print('Closing...')
        running = False
        trunning = False
        wrunning = False
        irrunning = False
        messagebox.showinfo("Quit Application", "Released Resources!!! You may close now...")
        self.destroy()
        # CloseMessageWindow("Quit Application", "Released Resources!!! You may close now...")
        print('Closed')
        print('END')


# Skeleton of the APP
## #####################################################################################################################


# Skeleton of the APP
## *********************************************************************************************************************
class MenuPage(tk.Frame):

    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        backload = Image.open("./img/background.jpg")
        backrender = ImageTk.PhotoImage(backload)
        back_lab = tk.Label(self, image=backrender)
        back_lab.pack()
        back_lab['bg'] = BACKGROUNDCOLCODE
        # back_lab.image = backrender
        back_lab.place(x=dc.backgroundFullImagePos[0], y=dc.backgroundFullImagePos[1])

        wifiload = Image.open("./img/wifi.png")
        wifirender = ImageTk.PhotoImage(wifiload)
        self.wifi_lab = tk.Label(self, image=wifirender)
        self.wifi_lab.pack()
        self.wifi_lab.image = wifirender
        self.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])

        # back_button = tk.Button(self, text='BACK', fg='red', width=10, height=2)
        # back_button.place(x=80,y=20)
        truck_lab = tk.Label(self, text='Active Truck ID:', font='Helvetica 14 bold', fg='brown')
        truck_lab.place(x=dc.activeTruckLabPos[0], y=dc.activeTruckLabPos[1])
        self.truckid_lab = tk.Label(self, text='NULL', font='Helvetica 14 bold', fg='blue')
        self.truckid_lab.place(x=dc.activeTruckIDPos[0], y=dc.activeTruckIDPos[1])

        homeload = Image.open("./img/home.png")
        homerender = ImageTk.PhotoImage(homeload)
        home_button = tk.Button(self, text='HOME', image=homerender, command=lambda: controller.show_frame(MenuPage))
        home_button.image = homerender
        home_button.place(x=dc.homeButtonPos[0], y=dc.homeButtonPos[1])

        logoload = Image.open("./img/logo.png")
        logorender = ImageTk.PhotoImage(logoload)
        company_lab = tk.Label(self, image=logorender)
        company_lab.pack()
        company_lab.image = logorender
        company_lab.place(x=dc.companyLogoPos[0], y=dc.companyLogoPos[1])

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line_lab = tk.Label(self, image=linerender)
        line_lab.pack()
        line_lab.image = linerender
        line_lab.place(x=dc.topHorzLinePos[0], y=dc.topHorzLinePos[1])

        ## --------------------------------------------------------------------------------------

        buttonload = Image.open("./img/single.png")
        buttonrender = ImageTk.PhotoImage(buttonload)
        single_button = tk.Button(self, image=buttonrender, command=lambda: controller.show_frame(SingleLoadPage))
        single_button.pack()
        single_button.image = buttonrender
        single_button.place(x=dc.homeSingleButtonPos[0], y=dc.homeSingleButtonPos[1])

        buttonload = Image.open("./img/combined.png")
        buttonrender = ImageTk.PhotoImage(buttonload)
        combined_button = tk.Button(self, image=buttonrender, command=lambda: controller.show_frame(CombinedLoadPage))
        combined_button.pack()
        combined_button.image = buttonrender
        combined_button.place(x=dc.homeCombinedButtonPos[0], y=dc.homeCombinedButtonPos[1])

        buttonload = Image.open("./img/reports.png")
        buttonrender = ImageTk.PhotoImage(buttonload)
        reports_button = tk.Button(self, image=buttonrender, command=lambda: controller.show_frame(ResultsLoadPage))
        reports_button.pack()
        reports_button.image = buttonrender
        reports_button.place(x=dc.homeReportsButtonPos[0], y=dc.homeReportsButtonPos[1])

        buttonload = Image.open("./img/setup.png")
        buttonrender = ImageTk.PhotoImage(buttonload)
        setup_button = tk.Button(self, image=buttonrender, command=lambda: controller.show_frame(SetupLoadPage))
        setup_button.pack()
        setup_button.image = buttonrender
        setup_button.place(x=dc.homeSetupButtonPos[0], y=dc.homeSetupButtonPos[1])

        ## ---------------------------------------------------------------------------

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line2_lab = tk.Label(self, image=linerender)
        line2_lab.pack()
        line2_lab.image = linerender
        line2_lab.place(x=dc.bottomHorzLinePos[0], y=dc.bottomHorzLinePos[1])

        self.time_lab = tk.Label(self, text="4:40 PM", font='Helvetica 14 bold')
        self.time_lab.pack(pady=0, padx=0)
        self.time_lab.place(x=dc.timeLabPos[0], y=dc.timeLabPos[1])
        self.date_lab = tk.Label(self, text="Friday, January 12, 2019", font='Helvetica 14 bold')
        self.date_lab.pack(pady=0, padx=0)
        self.date_lab.place(x=dc.dateLabPos[0], y=dc.dateLabPos[1])

        self.wifi_lab['bg'] = BACKGROUNDCOLCODE
        truck_lab['bg'] = BACKGROUNDCOLCODE
        self.truckid_lab['bg'] = BACKGROUNDCOLCODE
        company_lab['bg'] = BACKGROUNDCOLCODE
        line_lab['bg'] = BACKGROUNDCOLCODE
        line2_lab['bg'] = BACKGROUNDCOLCODE
        self.time_lab['bg'] = BACKGROUNDCOLCODE
        self.date_lab['bg'] = BACKGROUNDCOLCODE
        home_button['bg'] = BACKGROUNDCOLCODE
        single_button['bg'] = BACKGROUNDCOLCODE
        combined_button['bg'] = BACKGROUNDCOLCODE
        reports_button['bg'] = BACKGROUNDCOLCODE
        setup_button['bg'] = BACKGROUNDCOLCODE

        DateTimeThreadedTask(self).start()
        TruckIDThreadedTask(self).start()
        WifiThreadedTask(self).start()


class SingleLoadPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        backload = Image.open("./img/background.jpg")
        backrender = ImageTk.PhotoImage(backload)
        back_lab = tk.Label(self, image=backrender)
        back_lab.pack()
        back_lab['bg'] = BACKGROUNDCOLCODE
        # back_lab.image = backrender
        back_lab.place(x=dc.backgroundFullImagePos[0], y=dc.backgroundFullImagePos[1])

        wifiload = Image.open("./img/wifi.png")
        wifirender = ImageTk.PhotoImage(wifiload)
        self.wifi_lab = tk.Label(self, image=wifirender)
        self.wifi_lab.pack()
        self.wifi_lab.image = wifirender
        self.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])

        # back_button = tk.Button(self, text='BACK', fg='red', width=10, height=2)
        # back_button.place(x=80,y=15)
        truck_lab = tk.Label(self, text='Active Truck ID', font='Helvetica 14 bold', fg='brown')
        truck_lab.place(x=dc.activeTruckLabPos[0], y=dc.activeTruckLabPos[1])
        self.truckid_lab = tk.Label(self, text='NULL', font='Helvetica 14 bold', fg='blue')
        self.truckid_lab.place(x=dc.activeTruckIDPos[0], y=dc.activeTruckIDPos[1])

        homeload = Image.open("./img/home.png")
        homerender = ImageTk.PhotoImage(homeload)
        home_button = tk.Button(self, text='HOME', image=homerender, command=lambda: controller.show_frame(MenuPage))
        home_button.image = homerender
        home_button.place(x=dc.homeButtonPos[0], y=dc.homeButtonPos[1])

        logoload = Image.open("./img/logo.png")
        logorender = ImageTk.PhotoImage(logoload)
        company_lab = tk.Label(self, image=logorender)
        company_lab.pack()
        company_lab.image = logorender
        company_lab.place(x=dc.companyLogoPos[0], y=dc.companyLogoPos[1])

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line_lab = tk.Label(self, image=linerender)
        line_lab.pack()
        line_lab.image = linerender
        line_lab.place(x=dc.topHorzLinePos[0], y=dc.topHorzLinePos[1])

        ## --------------------------------------------------------------------------------------

        load = Image.open("./img/wait.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.singleBarImagePos[0], y=dc.singleBarImagePos[1])
        self.rs232 = RS232Serial.RS232Serial()
        self.INTERVAL = self.rs232.INTERVAL
        self.WEIGHTCHECKING = self.rs232.WEIGHTCHECKING


        #bl_lab = tk.Label(self, text='Status:', font='Helvetica 12', fg='brown')
        #bl_lab.place(x=dc.singleBLLabPos[0], y=dc.singleBLLabPos[1])

        #load = Image.open("./img/start-0.jpg")
        #render = ImageTk.PhotoImage(load)
        self.blstatus_lab = tk.Label(self, text='SCAN or ENTER B/L FIRST', font='Helvetica 12', fg='blue')
        #self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.singleBLStatusLabPos[0], y=dc.singleBLStatusLabPos[1])

        self.blcode_lab = tk.Label(self, text='SCAN FIRST', font='Helvetica 18 bold', fg='black', width=18)
        self.blcode_lab.configure(anchor="center")
        self.blcode_lab.place(x=dc.singleBLCodeLabPos[0], y=dc.singleBLCodeLabPos[1])

        helv1 = font.Font(family='Helvetica', size=14, weight=font.NORMAL)
        helv2 = font.Font(family='Helvetica', size=14, weight=font.BOLD)
        self.undobl_button = tk.Button(self, text='Undo', fg='blue', width=22, height=2, font=helv1,
                                       command=self.undoIRScanCom)
        self.undobl_button.place(x=dc.singleUndoButtonPos[0], y=dc.singleUndoButtonPos[1])
        self.scanbl_button = tk.Button(self, text='SCAN B/L', fg='red', width=22, height=2, font=helv2,
                                       command=self.startIRScanCom)
        self.scanbl_button.place(x=dc.singleBLScanButtonPos[0], y=dc.singleBLScanButtonPos[1])

        self.singleBLKeyboardButton = tk.Button(self, text='Enter B/L', fg='green', width=22, height=2, font=helv1,
                                                command=self.startIRKeyboard)
        self.singleBLKeyboardButton.place(x=dc.singleBLKeyboardButtonPos[0], y=dc.singleBLKeyboardButtonPos[1])

        # self.start_button.config(state='normal')
        # self.capture_button.config(state='disabled')

        ## ---------------------------------------------------------------------------

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line2_lab = tk.Label(self, image=linerender)
        line2_lab.pack()
        line2_lab.image = linerender
        line2_lab.place(x=dc.bottomHorzLinePos[0], y=dc.bottomHorzLinePos[1])

        self.time_lab = tk.Label(self, text="4:40 PM", font='Helvetica 14 bold')
        self.time_lab.pack(pady=0, padx=0)
        self.time_lab.place(x=dc.timeLabPos[0], y=dc.timeLabPos[1])
        self.date_lab = tk.Label(self, text="Friday, January 12, 2019", font='Helvetica 14 bold')
        self.date_lab.pack(pady=0, padx=0)
        self.date_lab.place(x=dc.dateLabPos[0], y=dc.dateLabPos[1])

        self.wifi_lab['bg'] = BACKGROUNDCOLCODE
        truck_lab['bg'] = BACKGROUNDCOLCODE
        self.truckid_lab['bg'] = BACKGROUNDCOLCODE
        company_lab['bg'] = BACKGROUNDCOLCODE
        line_lab['bg'] = BACKGROUNDCOLCODE
        line2_lab['bg'] = BACKGROUNDCOLCODE
        self.time_lab['bg'] = BACKGROUNDCOLCODE
        self.date_lab['bg'] = BACKGROUNDCOLCODE
        home_button['bg'] = BACKGROUNDCOLCODE
        #bl_lab['bg'] = BACKGROUNDCOLCODE
        self.blstatus_lab['bg'] = BACKGROUNDCOLCODE

        DateTimeThreadedTask(self).start()
        TruckIDThreadedTask(self).start()
        WifiThreadedTask(self).start()

        self.IR = IRScanner.IRScanner()

    def undoIRScanCom(self):
        global oldBarCode,singleBarCode
        if oldBarCode != None:
            self.blcode_lab['text'] = oldBarCode
            self.changeProcStatus("UNDO OLD B/L. READING WEIGHT")
            singleBarCode = oldBarCode
    """
    def changeProcStatusStart(self):
        print('Status Change')
        load = Image.open("./img/start-0.jpg")
        render = ImageTk.PhotoImage(load)
        self.blstatus_lab = Label(self, image=render)
        self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.singleBLStatusLabPos[0], y=dc.singleBLStatusLabPos[1])

    def changeProcStatusScan(self):
        print('Status Change')
        load = Image.open("./img/scan-1.jpg")
        render = ImageTk.PhotoImage(load)
        self.blstatus_lab = Label(self, image=render)
        self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.singleBLStatusLabPos[0], y=dc.singleBLStatusLabPos[1])

    def changeProcStatusWeight(self, ch):
        print('Status Change')
        if ch == 1:
            load = Image.open("./img/weight-2-1.jpg")
        else:
            load = Image.open("./img/weight-2-2.jpg")
        render = ImageTk.PhotoImage(load)
        self.blstatus_lab = Label(self, image=render)
        self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.singleBLStatusLabPos[0], y=dc.singleBLStatusLabPos[1])

    def changeProcStatusSave(self, ch):
        print('Status Change')
        if ch == 1:
            load = Image.open("./img/save-3-1.jpg")
        else:
            load = Image.open("./img/save-3-2.jpg")
        render = ImageTk.PhotoImage(load)
        self.blstatus_lab = Label(self, image=render)
        self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.singleBLStatusLabPos[0], y=dc.singleBLStatusLabPos[1])
    """

    def changeProcStatus(self, msg):
        #print('Status Change')
        self.blstatus_lab["text"] = msg
    def changeBLCodeStatus(self, msg):
        #print('Status Change')
        self.blcode_lab["text"] = msg

    def startIRScanCom(self):
        try:
            #print('startIRScanCom')
            irbarcode = self.IR.scanIRCODE()
            self.blcode_lab["text"] = irbarcode
            global singleBarCode
            if irbarcode != 'ERROR':
                singleBarCode = irbarcode
                self.changeProcStatus("B/L SCAN DONE. READING WEIGHT")
        except:
            print('startIRScanCom Error')

    def closeCom(self):
        global running
        try:
            running = False
            # self.start_button.config(state='normal')
            # self.capture_button.config(state='disabled')

        except:
            print('closeCom Error')
            self.showDevError()

    def initComm(self):
        try:
            self.resetItems()
            stat = self.rs232.checkSerial()
            self.rsserial = self.rs232.ser
            print(stat)
            if stat == True:
                # self.start_button.config(state='disabled')
                # self.capture_button.config(state='normal')
                global running
                running = True
                SingleLoadThreadedTask(self).start()
            else:
                self.showDevError()
                print('No Device Found')
        except:
            print('initCom Error')
            self.showDevError()

    def showError(self):
        load = Image.open("./img/error.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.singleBarImagePos[0], y=dc.singleBarImagePos[1])

    def showDevError(self):
        load = Image.open("./img/device.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.singleBarImagePos[0], y=dc.singleBarImagePos[1])

    def updateImage(self, wtype):
        if wtype == 'KG':
            fimg = Image.open("./img/kg.jpg")
        else:
            fimg = Image.open("./img/lbs.jpg")
        bar = Image.open("./img/barcode.png")
        basewidth, height = bar.size
        # wpercent = (basewidth / float(fimg.size[0]))
        # hsize = int((float(fimg.size[1]) * float(wpercent)))
        fimg = fimg.resize((basewidth, 55), Image.ANTIALIAS)
        img_merge = np.vstack((np.asarray(bar), np.asarray(fimg)))
        img_merge = Image.fromarray(img_merge)
        img = img_merge.resize((480, 320), Image.ANTIALIAS)
        # img.save('./img/barcode_resize.jpg')
        # load = Image.open("./img/barcode_resize.jpg")
        render = ImageTk.PhotoImage(img)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.singleBarImagePos[0], y=dc.singleBarImagePos[1])

    def startIRKeyboard(self):
        print('startIRKeyboard')
        self.wid = popupKeyBoardWindow("Enter B/L BARCODE ENTRY","ENTER BARCODE",0)
        self.master.wait_window(self.wid)
        print(self.entryValue())
        try:
            if len(self.entryValue()) > 0:
                self.blcode_lab["text"] = self.entryValue()
                global singleBarCode
                singleBarCode = self.entryValue()
                self.changeProcStatus("Enter B/L B/L DONE. READING WEIGHT")
        except Exception as e:
            print('startIRKeyboard', e)

    def entryValue(self):
        try:
            keyval = self.wid.value
        except:
            keyval = ''
        finally:
            return keyval

    def resetItems(self):
        global singleBarCode
        singleBarCode = None
        load = Image.open("./img/wait.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.singleBarImagePos[0], y=dc.singleBarImagePos[1])

        self.blcode_lab["text"] = 'SCAN FIRST'
        self.blstatus_lab["text"] = 'SCAN or ENTER B/L FIRST'


class CombinedLoadPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        backload = Image.open("./img/background.jpg")
        backrender = ImageTk.PhotoImage(backload)
        back_lab = tk.Label(self, image=backrender)
        back_lab.pack()
        back_lab['bg'] = BACKGROUNDCOLCODE
        # back_lab.image = backrender
        back_lab.place(x=dc.backgroundFullImagePos[0], y=dc.backgroundFullImagePos[1])

        wifiload = Image.open("./img/wifi.png")
        wifirender = ImageTk.PhotoImage(wifiload)
        self.wifi_lab = tk.Label(self, image=wifirender)
        self.wifi_lab.pack()
        self.wifi_lab.image = wifirender
        self.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])

        # back_button = tk.Button(self, text='BACK', fg='red', width=10, height=2)
        # back_button.place(x=80,y=15)
        truck_lab = tk.Label(self, text='Active Truck ID', font='Helvetica 14 bold', fg='brown')
        truck_lab.place(x=dc.activeTruckLabPos[0], y=dc.activeTruckLabPos[1])
        self.truckid_lab = tk.Label(self, text='NULL', font='Helvetica 14 bold', fg='blue')
        self.truckid_lab.place(x=dc.activeTruckIDPos[0], y=dc.activeTruckIDPos[1])

        homeload = Image.open("./img/home.png")
        homerender = ImageTk.PhotoImage(homeload)
        home_button = tk.Button(self, text='HOME', image=homerender, command=lambda: controller.show_frame(MenuPage))
        home_button.image = homerender
        home_button.place(x=dc.homeButtonPos[0], y=dc.homeButtonPos[1])

        logoload = Image.open("./img/logo.png")
        logorender = ImageTk.PhotoImage(logoload)
        company_lab = tk.Label(self, image=logorender)
        company_lab.pack()
        company_lab.image = logorender
        company_lab.place(x=dc.companyLogoPos[0], y=dc.companyLogoPos[1])

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line_lab = tk.Label(self, image=linerender)
        line_lab.pack()
        line_lab.image = linerender
        line_lab.place(x=dc.topHorzLinePos[0], y=dc.topHorzLinePos[1])

        ## --------------------------------------------------------------------------------------

        load = Image.open("./img/wait.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.doubleBarImagePos[0], y=dc.doubleBarImagePos[1])
        self.rs232 = RS232Serial.RS232Serial()
        self.INTERVAL = self.rs232.INTERVAL
        self.WEIGHTCHECKING = self.rs232.WEIGHTCHECKING

        #bl_lab = tk.Label(self, text='Status:', font='Helvetica 12', fg='brown')
        #bl_lab.place(x=dc.doubleBLLabPos[0], y=dc.doubleBLLabPos[1])

        #load = Image.open("./img/start-0.jpg")
        #render = ImageTk.PhotoImage(load)
        self.blstatus_lab = tk.Label(self, text='SCAN or ENTER B/L FIRST', font='Helvetica 12', fg='blue')
        #self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.doubleBLStatusLabPos[0], y=dc.doubleBLStatusLabPos[1])

        self.blcode_lab = tk.Label(self, text='SCAN FIRST', font='Helvetica 18 bold', fg='black', width=18)
        self.blcode_lab.configure(anchor="center")
        self.blcode_lab.place(x=dc.doubleBLCodeLabPos[0], y=dc.doubleBLCodeLabPos[1])

        self.undobl_button = tk.Button(self, text='Undo', fg='blue', width=8, height=2, command=self.undoIRScanCom)
        self.undobl_button.place(x=dc.doubleUndoButtonPos[0], y=dc.doubleUndoButtonPos[1])
        self.scanbl_button = tk.Button(self, text='SCAN B/L', fg='red', width=8, height=2, command=self.startIRScanCom)
        self.scanbl_button.place(x=dc.doubleBLScanButtonPos[0], y=dc.doubleBLScanButtonPos[1])
        self.keyboardbl_button = tk.Button(self, text='Enter B/L', fg='green', width=8, height=2,
                                           command=self.startIRKeyboard)
        self.keyboardbl_button.place(x=dc.doubleBLKeyboardButtonPos[0], y=dc.doubleBLKeyboardButtonPos[1])

        helv2 = font.Font(family='Helvetica', size=14, weight=font.BOLD)
        self.start_button = tk.Button(self, text='START LOAD', fg='blue', width=22, height=2, font=helv2,
                                      command=self.initComm)
        self.start_button.place(x=dc.doubleStartButtonPos[0], y=dc.doubleStartButtonPos[1])
        self.next_button = tk.Button(self, text='CAPTURE & NEXT', fg='blue', width=22, height=2, font=helv2,
                                     command=self.nextCom)
        self.next_button.place(x=dc.doubleNextButtonPos[0], y=dc.doubleNextButtonPos[1])
        self.finish_button = tk.Button(self, text='CAPTURE & FINISH', fg='blue', width=22, height=2, font=helv2,
                                       command=self.finishCom)
        self.finish_button.place(x=dc.doubleFinishButtonPos[0], y=dc.doubleFinishButtonPos[1])

        self.start_button.config(state='normal')
        self.next_button.config(state='disabled')
        self.finish_button.config(state='disabled')

        ## ---------------------------------------------------------------------------

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line2_lab = tk.Label(self, image=linerender)
        line2_lab.pack()
        line2_lab.image = linerender
        line2_lab.place(x=dc.bottomHorzLinePos[0], y=dc.bottomHorzLinePos[1])

        self.time_lab = tk.Label(self, text="4:40 PM", font='Helvetica 14 bold')
        self.time_lab.pack(pady=0, padx=0)
        self.time_lab.place(x=dc.timeLabPos[0], y=dc.timeLabPos[1])
        self.date_lab = tk.Label(self, text="Friday, January 12, 2019", font='Helvetica 14 bold')
        self.date_lab.pack(pady=0, padx=0)
        self.date_lab.place(x=dc.dateLabPos[0], y=dc.dateLabPos[1])

        self.wifi_lab['bg'] = BACKGROUNDCOLCODE
        truck_lab['bg'] = BACKGROUNDCOLCODE
        self.truckid_lab['bg'] = BACKGROUNDCOLCODE
        company_lab['bg'] = BACKGROUNDCOLCODE
        line_lab['bg'] = BACKGROUNDCOLCODE
        line2_lab['bg'] = BACKGROUNDCOLCODE
        self.time_lab['bg'] = BACKGROUNDCOLCODE
        self.date_lab['bg'] = BACKGROUNDCOLCODE
        home_button['bg'] = BACKGROUNDCOLCODE
        #bl_lab['bg'] = BACKGROUNDCOLCODE
        self.blstatus_lab['bg'] = BACKGROUNDCOLCODE

        DateTimeThreadedTask(self).start()
        TruckIDThreadedTask(self).start()
        WifiThreadedTask(self).start()

        self.IR = IRScanner.IRScanner()

    def undoIRScanCom(self):
        global oldBarCode, combinedBarCode
        if oldBarCode != None:
            self.blcode_lab['text'] = oldBarCode
            self.changeProcStatus("UNDO OLD B/L. START LOAD NOW")
            combinedBarCode = oldBarCode

    def changeProcStatus(self,msg):
        #print('Status Change')
        self.blstatus_lab["text"] = msg
    def changeProcStatus2(self,msg):
        time.sleep(0.5)
        self.blstatus_lab["text"] = msg
    """
    def changeProcStatusScan(self):
        print('Status Change')
        load = Image.open("./img/scan-1.jpg")
        render = ImageTk.PhotoImage(load)
        self.blstatus_lab = Label(self, image=render)
        self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.doubleBLStatusLabPos[0], y=dc.doubleBLStatusLabPos[1])

    def changeProcStatusWeight(self, ch):
        print('Status Change')
        if ch == 1:
            load = Image.open("./img/weight-2-1.jpg")
        else:
            load = Image.open("./img/weight-2-2.jpg")
        render = ImageTk.PhotoImage(load)
        self.blstatus_lab = Label(self, image=render)
        self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.doubleBLStatusLabPos[0], y=dc.doubleBLStatusLabPos[1])

    def changeProcStatusSave(self, ch):
        print('Status Change')
        if ch == 1:
            load = Image.open("./img/save-3-1.jpg")
        else:
            load = Image.open("./img/save-3-2.jpg")
        render = ImageTk.PhotoImage(load)
        self.blstatus_lab = Label(self, image=render)
        self.blstatus_lab.iamge = render
        self.blstatus_lab.place(x=dc.doubleBLStatusLabPos[0], y=dc.doubleBLStatusLabPos[1])
    """
    def startIRKeyboard(self):
        #print('startIRKeyboard')
        self.wid = popupKeyBoardWindow("Enter B/L BARCODE ENTRY","ENTER BARCODE",0)
        self.master.wait_window(self.wid)
        #print(self.entryValue())
        try:
            if len(self.entryValue()) > 0:
                self.blcode_lab["text"] = str(self.entryValue())
                global combinedBarCode
                combinedBarCode = self.entryValue()
                self.changeProcStatus("Enter B/L B/L DONE. START LOAD NOW")
        except Exception as e:
            print('startIRKeyboard', e)

    def entryValue(self):
        try:
            keyval = self.wid.value
        except:
            keyval = ''
        finally:
            return keyval

    def startIRScanCom(self):
        global combinedBarCode
        try:
            #print('startIRScanCom')
            irbarcode = self.IR.scanIRCODE()
            self.blcode_lab["text"] = irbarcode
            if irbarcode != 'ERROR':
                combinedBarCode = irbarcode
                self.changeProcStatus("B/L SCAN DONE. START LOAD NOW")
        except:
            print('startIRScanCom Error')

    def finishCom(self):
        global running
        global combinedBarCode, oldBarCode, activeTruckID
        if combinedWeight != None:
            try:
                running = False
                self.start_button.config(state='normal')
                self.next_button.config(state='disabled')
                self.finish_button.config(state='disabled')
                # print('---------------', self.TotalWeight)
                if self.WeightType == 'KG':
                    weight = self.TotalWeight
                else:
                    weight = self.TotalWeight / 2.20462
                value = "{0:.4f}".format(weight)
                value = self.dropzeros(value)
                # print('---------------', value)
                EAN = barcode.get_barcode_class('code128')
                from barcode.writer import ImageWriter
                ean = EAN(str(value), writer=ImageWriter())
                fullname = ean.save('./img/barcodec')
                if self.WeightType == 'KG':
                    fimg = Image.open("./img/kg.jpg")
                else:
                    fimg = Image.open("./img/lbs.jpg")
                bar = Image.open("./img/barcodec.png")
                basewidth, height = bar.size
                # wpercent = (basewidth / float(fimg.size[0]))
                # hsize = int((float(fimg.size[1]) * float(wpercent)))
                fimg = fimg.resize((basewidth, 55), Image.ANTIALIAS)
                img_merge = np.vstack((np.asarray(bar), np.asarray(fimg)))
                img_merge = Image.fromarray(img_merge)
                img = img_merge.resize((480, 320), Image.ANTIALIAS)
                # img.save('./img/barcode_resize.jpg')
                # load = Image.open("./img/barcode_resize.jpg")
                render = ImageTk.PhotoImage(img)
                self.img = Label(self, image=render)
                self.img.image = render
                self.img.place(x=dc.doubleBarImagePos[0], y=dc.doubleBarImagePos[1])

                if combinedBarCode != None:
                    self.changeProcStatus("DATA SAVED WITH B/L. SCAN NEW")
                else:
                    self.changeProcStatus("DATA SAVED WITHOUT B/L. SCAN NEW")

                if combinedBarCode != None:
                    scancode = combinedBarCode

                elif combinedBarCode == 'ERROR':
                    scancode = 'NO DATA'
                else:
                    scancode = 'NO DATA'

                now = datetime.now()
                date_time = now.strftime("%m/%d/%Y %H:%M:%S")
                self.insertData([activeTruckID, str(value), self.WeightType, scancode, 'COMBINE2', date_time])
                oldBarCode = combinedBarCode
                combinedBarCode = None
                # time.sleep(2)
                # t = threading.Thread(target=self.changeProcStatusStart(), args=())
                # t.start()
                # self.blcode_lab['text'] = 'SCAN AGAIN'
                self.undobl_button.config(state='normal')
                self.scanbl_button.config(state='normal')
                self.keyboardbl_button.config(state='normal')
                #self.changeProcStatus("DATA SAVED. DO NEW B/L SCAN")

            except Exception as e:
                print('finishCom Error:', e)
                self.showDevError()

    def dropzeros(self, number):
        mynum = decimal.Decimal(number).normalize()
        return mynum.__trunc__() if not mynum % 1 else float(mynum)

    def nextCom(self):
        global running
        global combinedWeight, combinedBarCode
        if combinedWeight != None and combinedWeight != 0:
            #print('Next CAPTURE')
            try:
                self.changeProcStatus("Successfully Captured, continue to next load")
                #self.start_button.config(state='disabled')
                #self.next_button.config(state='normal')
                self.finish_button.config(state='normal')
                if self.WeightType == 'KG':
                    weight = (float)(combinedWeight)
                else:
                    weight = (float)(combinedWeight) * 2.20462
                self.TotalWeight = self.TotalWeight + weight
                # self.TotalWeight = self.TotalWeight+self.currentWeight
                #self.changeProcStatus("PROCEED TO CAPTURE NEXT WEIGHT")
                t1 =threading.Thread(target=self.changeProcStatus2, args=("PROCEED TO CAPTURE NEXT WEIGHT",))
                t1.start()
                #t1.join()
            except:
                print('nextCom Error')
                self.showDevError()

    def initComm(self):
        global combinedWeight, combinedBarCode
        try:
            #self.resetItems()
            stat = self.rs232.checkSerial()
            self.rsserial = self.rs232.ser
            print(stat)
            if stat == True:
                self.start_button.config(state='disabled')
                self.next_button.config(state='normal')
                self.finish_button.config(state='disabled')
                combinedWeight = 0.0
                self.TotalWeight = 0.0
                self.WeightType = ''
                global running
                running = True
                self.undobl_button.config(state='disabled')
                self.scanbl_button.config(state='disabled')
                self.keyboardbl_button.config(state='disabled')
                self.changeProcStatus("WEIGHT LOADED. CAPTURE WEIGHT")
                if combinedBarCode !=None:
                    self.blcode_lab['text']=combinedBarCode
                CombinedLoadThreadedTask(self).start()
            else:
                self.showDevError()
                print('No Device Found')
        except:
            print('initCom Error')
            self.showDevError()

    def showError(self):
        load = Image.open("./img/error.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.doubleBarImagePos[0], y=dc.doubleBarImagePos[1])

    def showDevError(self):
        load = Image.open("./img/device.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.doubleBarImagePos[0], y=dc.doubleBarImagePos[1])

    def updateImage(self, wtype):
        self.WeightType = wtype
        if wtype == 'KG':
            fimg = Image.open("./img/kg.jpg")
        else:
            fimg = Image.open("./img/lbs.jpg")
        bar = Image.open("./img/barcode.png")
        basewidth, height = bar.size
        # wpercent = (basewidth / float(fimg.size[0]))
        # hsize = int((float(fimg.size[1]) * float(wpercent)))
        fimg = fimg.resize((basewidth, 55), Image.ANTIALIAS)
        img_merge = np.vstack((np.asarray(bar), np.asarray(fimg)))
        img_merge = Image.fromarray(img_merge)
        img = img_merge.resize((480, 320), Image.ANTIALIAS)
        # img.save('./img/barcode_resize.jpg')
        # load = Image.open("./img/barcode_resize.jpg")
        render = ImageTk.PhotoImage(img)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.doubleBarImagePos[0], y=dc.doubleBarImagePos[1])

    def insertData(self, data):
        #print('Storing into DB')
        try:
            conn = sqlite3.connect('./db/weightrpi.db')
            sql = 'INSERT INTO tbl_weight_info(truckid,weight,measurement,barcode, scantype,recorded) VALUES (?,?,?,?,?,?)'
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
        except Error as e:
            print(e)
        finally:
            conn.close()

        chw = float(data[1])
        meas = str(data[2])
        if meas == 'KG':
            chw = chw * 2.20462
        if chw > 5000.0:
            try:
                conn = sqlite3.connect('./db/weightfiverpi.db')
                sql = 'INSERT INTO tbl_weight_five_info(truckid,weight,measurement,barcode, scantype,recorded) VALUES (?,?,?,?,?,?)'
                cur = conn.cursor()
                cur.execute(sql, data)
                conn.commit()
            except Error as e:
                print(e)
            finally:
                conn.close()

    def resetItems(self):
        global combinedBarCode
        combinedBarCode = None

        load = Image.open("./img/wait.jpg")
        render = ImageTk.PhotoImage(load)
        self.img = Label(self, image=render)
        self.img.image = render
        self.img.place(x=dc.singleBarImagePos[0], y=dc.singleBarImagePos[1])
        self.blstatus_lab["text"] = 'SCAN or ENTER B/L FIRST'

        self.blcode_lab["text"] = 'SCAN FIRST'

        self.undobl_button.config(state='normal')
        self.scanbl_button.config(state='normal')
        self.keyboardbl_button.config(state='normal')
        self.start_button.config(state='normal')
        self.next_button.config(state='disabled')
        self.finish_button.config(state='disabled')


class ResultsLoadPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        backload = Image.open("./img/background.jpg")
        backrender = ImageTk.PhotoImage(backload)
        back_lab = tk.Label(self, image=backrender)
        back_lab.pack()
        back_lab['bg'] = BACKGROUNDCOLCODE
        # back_lab.image = backrender
        back_lab.place(x=dc.backgroundFullImagePos[0], y=dc.backgroundFullImagePos[1])

        wifiload = Image.open("./img/wifi.png")
        wifirender = ImageTk.PhotoImage(wifiload)
        self.wifi_lab = tk.Label(self, image=wifirender)
        self.wifi_lab.pack()
        self.wifi_lab.image = wifirender
        self.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])

        # back_button = tk.Button(self, text='BACK', fg='red', width=10, height=2)
        # back_button.place(x=80,y=15)
        truck_lab = tk.Label(self, text='Active Truck ID', font='Helvetica 14 bold', fg='brown')
        truck_lab.place(x=dc.activeTruckLabPos[0], y=dc.activeTruckLabPos[1])
        self.truckid_lab = tk.Label(self, text='NULL', font='Helvetica 14 bold', fg='blue')
        self.truckid_lab.place(x=dc.activeTruckIDPos[0], y=dc.activeTruckIDPos[1])

        homeload = Image.open("./img/home.png")
        homerender = ImageTk.PhotoImage(homeload)
        home_button = tk.Button(self, text='HOME', image=homerender, command=lambda: controller.show_frame(MenuPage))
        home_button.image = homerender
        home_button.place(x=dc.homeButtonPos[0], y=dc.homeButtonPos[1])

        logoload = Image.open("./img/logo.png")
        logorender = ImageTk.PhotoImage(logoload)
        company_lab = tk.Label(self, image=logorender)
        company_lab.pack()
        company_lab.image = logorender
        company_lab.place(x=dc.companyLogoPos[0], y=dc.companyLogoPos[1])

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line_lab = tk.Label(self, image=linerender)
        line_lab.pack()
        line_lab.image = linerender
        line_lab.place(x=dc.topHorzLinePos[0], y=dc.topHorzLinePos[1])

        ## --------------------------------------------------------------------------------------
        # Rest, Truck, Wifi, Date
        helv2 = font.Font(family='Helvetica', size=16, weight=font.BOLD)

        self.emailcsv_button = tk.Button(self, text='EXPORT CSV CLEAR DATA', fg='blue', width=22, height=2, font=helv2,
                                         command=self.exportCSVDel)
        self.emailcsv_button.place(x=dc.reportEmailCSVButtonPos[0], y=dc.reportEmailCSVButtonPos[1])
        self.emailhtml_button = tk.Button(self, text='EXPORT CSV KEEP DATA', fg='blue', width=22, height=2, font=helv2,
                                          command=self.exportCSVKeep)
        self.emailhtml_button.place(x=dc.reportEmailHTMLButtonPos[0], y=dc.reportEmailHTMLButtonPos[1])
        self.exportcsv_button = tk.Button(self, text='EMAIL CSV CLEAR DATA', fg='blue', width=22, height=2, font=helv2,
                                          command=self.sendEmailClear)
        self.exportcsv_button.place(x=dc.reportExportCSVButtonPos[0], y=dc.reportExportCSVButtonPos[1])
        self.exportall_button = tk.Button(self, text='EMAIL CSV KEEP DATA', fg='blue', width=22, height=2, font=helv2,command=self.sendEmailKeep)
        self.exportall_button.place(x=dc.reportExportAllButtonPos[0], y=dc.reportExportAllButtonPos[1])

        ## ---------------------------------------------------------------------------

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line2_lab = tk.Label(self, image=linerender)
        line2_lab.pack()
        line2_lab.image = linerender
        line2_lab.place(x=dc.bottomHorzLinePos[0], y=dc.bottomHorzLinePos[1])

        self.time_lab = tk.Label(self, text="4:40 PM", font='Helvetica 14 bold')
        self.time_lab.pack(pady=0, padx=0)
        self.time_lab.place(x=dc.timeLabPos[0], y=dc.timeLabPos[1])
        self.date_lab = tk.Label(self, text="Friday, January 12, 2019", font='Helvetica 14 bold')
        self.date_lab.pack(pady=0, padx=0)
        self.date_lab.place(x=dc.dateLabPos[0], y=dc.dateLabPos[1])

        self.wifi_lab['bg'] = BACKGROUNDCOLCODE
        truck_lab['bg'] = BACKGROUNDCOLCODE
        self.truckid_lab['bg'] = BACKGROUNDCOLCODE
        company_lab['bg'] = BACKGROUNDCOLCODE
        line_lab['bg'] = BACKGROUNDCOLCODE
        line2_lab['bg'] = BACKGROUNDCOLCODE
        self.time_lab['bg'] = BACKGROUNDCOLCODE
        self.date_lab['bg'] = BACKGROUNDCOLCODE
        home_button['bg'] = BACKGROUNDCOLCODE

        DateTimeThreadedTask(self).start()
        TruckIDThreadedTask(self).start()
        WifiThreadedTask(self).start()

    def getSDPath(self):
        path = '/media/pi/*/'
        dirs = glob(path)
        if len(dirs) > 0:
            path = dirs[0]
        else:
            path = os.getcwd()
            path = path + '/'
        now = datetime.now()
        date_time = now.strftime("%m-%d-%Y-%H-%M-%S")
        filepath = path + 'ALL_' + date_time + '.csv'
        return filepath

    def exportCSVDel(self):
        #print('Export and Clear')
        directorypath = self.getSDPath()
        if not directorypath:
            messagebox.showinfo("Task Error", "Error Occured")
        else:
            csvc = GenCSVDeleteData.GenCSVDeleteData()
            csvc.doTask(directorypath)
            messagebox.showinfo("Data Task", "CSV File Created and Database Cleared\nPath:" + directorypath)
            csvc.clearData()

    def exportCSVKeep(self):
        #print('Export and Keep')
        directorypath = self.getSDPath()
        if not directorypath:
            messagebox.showinfo("Task Error", "Error Occured")
        else:
            csvc = GenCSVKeepData.GenCSVKeepData()
            csvc.doTask(directorypath)
            messagebox.showinfo("Data Task", "CSV File Created and Database Kept\nPath:" + directorypath)

    def sendEmailKeep(self):
        self.w = emailDialogWindow(self.master)
        # self.b["state"] = "disabled"
        self.master.wait_window(self.w.top)
        # self.b["state"] = "normal"

        try:
            if self.w.emailStat == True:
                global activeTruckID
                if activeTruckID != None:
                    truckid = activeTruckID
                else:
                    truckid = 'NA'
                now = datetime.now()
                date_time = now.strftime("%m/%d/%Y-%H:%M:%S")

                subject = truckid + '-Weight Report ' + date_time
                message = 'Please see attached CSV Weight report taken for ' + truckid + ' - ' + date_time

                filepath = './db/' + truckid + '.csv'
                csvc = GenCSVKeepData.GenCSVKeepData()
                csvc.doTask(filepath)
                attachments = [filepath]
                senderemail = self.w.emailid
                [smtp_server, smtp_port, smtp_email, smtp_pwd, smtp_ccemail] = self.getSMTPConfig()
                smtp_ccemail = senderemail
                print('Connecting to server...')
                server = EmailSetup.EmailConnection(smtp_server, smtp_port, smtp_email, smtp_pwd)
                print('Preparing the email...')
                email = EmailSetup.Email(from_='<%s>' % (smtp_email),  # you can pass only email
                                         to='<%s>' % (smtp_ccemail),  # you can pass only email
                                         subject=subject, message=message, attachments=attachments)
                print('Sending...')
                server.send(email)
                print('Disconnecting...')
                server.close()
                print('Done!')
                messagebox.showinfo("Email Task", "Email Sent Successfully!!!")
        except:
            print('Error Occured')
            messagebox.showinfo("Email Task", "Sorry !!! Email Sent Unsucessfull")

    def sendEmailClear(self):
        self.w = emailDialogWindow(self.master)
        # self.b["state"] = "disabled"
        self.master.wait_window(self.w.top)
        # self.b["state"] = "normal"

        try:
            if self.w.emailStat == True:
                global activeTruckID
                if activeTruckID != None:
                    truckid = activeTruckID
                else:
                    truckid = 'NA'
                now = datetime.now()
                date_time = now.strftime("%m/%d/%Y-%H:%M:%S")

                subject = truckid + '-Weight Report ' + date_time
                message = 'Please see attached CSV Weight report taken for ' + truckid + ' - ' + date_time

                filepath = './db/' + truckid + '.csv'
                csvc = GenCSVDeleteData.GenCSVDeleteData()
                csvc.doTask(filepath)
                attachments = [filepath]
                senderemail = self.w.emailid
                [smtp_server, smtp_port, smtp_email, smtp_pwd, smtp_ccemail] = self.getSMTPConfig()
                smtp_ccemail = senderemail
                print('Connecting to server...')
                server = EmailSetup.EmailConnection(smtp_server, smtp_port, smtp_email, smtp_pwd)
                print('Preparing the email...')
                email = EmailSetup.Email(from_='<%s>' % (smtp_email),  # you can pass only email
                                         to='<%s>' % (smtp_ccemail),  # you can pass only email
                                         subject=subject, message=message, attachments=attachments)
                print('Sending...')
                server.send(email)
                print('Disconnecting...')
                server.close()
                print('Done!')
                messagebox.showinfo("Email Task", "Email Sent Successfully!!!")
                csvc.clearData()
        except:
            print('Error Occured')
            messagebox.showinfo("Email Task", "Sorry !!! Email Sent Unsucessfull")

    def getSMTPConfig(self):
        smtp_server = None
        smtp_port = None
        smtp_email = None
        smtp_pwd = None
        smtp_ccemail = None
        try:
            file = pathlib.Path("./db/smtpconfig.dat")
            if file.exists():
                new_file = open("./db/smtpconfig.dat", mode="rb")
                line = new_file.readline()
                new_file.close()
                if not line:
                    smtp_server = ''
                    smtp_port = ''
                    smtp_email = ''
                    smtp_pwd = ''
                    smtp_ccemail = ''
                else:
                    x = line.decode('UTF-8')
                    y = json.loads(x)
                    smtp_server = y["SERVER"]
                    smtp_port = y["PORT"]
                    smtp_email = y["EMAIL"]
                    smtp_pwd = y["PASSWORD"]
                    smtp_ccemail = y["CC"]

        except:
            smtp_server = ''
            smtp_port = ''
            smtp_email = ''
            smtp_pwd = ''
            smtp_ccemail = ''
        finally:
            return [smtp_server, smtp_port, smtp_email, smtp_pwd, smtp_ccemail]


class SetupLoadPage(tk.Frame):
    def __init__(self, parent, controller):
        tk.Frame.__init__(self, parent)

        backload = Image.open("./img/background.jpg")
        backrender = ImageTk.PhotoImage(backload)
        back_lab = tk.Label(self, image=backrender)
        back_lab.pack()
        back_lab['bg'] = BACKGROUNDCOLCODE
        # back_lab.image = backrender
        back_lab.place(x=dc.backgroundFullImagePos[0], y=dc.backgroundFullImagePos[1])

        wifiload = Image.open("./img/wifi.png")
        wifirender = ImageTk.PhotoImage(wifiload)
        self.wifi_lab = tk.Label(self, image=wifirender)
        self.wifi_lab.pack()
        self.wifi_lab.image = wifirender
        self.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])

        # back_button = tk.Button(self, text='BACK', fg='red', width=10, height=2)
        # back_button.place(x=80,y=15)
        truck_lab = tk.Label(self, text='Active Truck ID', font='Helvetica 14 bold', fg='brown')
        truck_lab.place(x=dc.activeTruckLabPos[0], y=dc.activeTruckLabPos[1])
        self.truckid_lab = tk.Label(self, text='NULL', font='Helvetica 14 bold', fg='blue')
        self.truckid_lab.place(x=dc.activeTruckIDPos[0], y=dc.activeTruckIDPos[1])

        homeload = Image.open("./img/home.png")
        homerender = ImageTk.PhotoImage(homeload)
        home_button = tk.Button(self, text='HOME', image=homerender, command=lambda: controller.show_frame(MenuPage))
        home_button.image = homerender
        home_button.place(x=dc.homeButtonPos[0], y=dc.homeButtonPos[1])

        logoload = Image.open("./img/logo.png")
        logorender = ImageTk.PhotoImage(logoload)
        company_lab = tk.Label(self, image=logorender)
        company_lab.pack()
        company_lab.image = logorender
        company_lab.place(x=dc.companyLogoPos[0], y=dc.companyLogoPos[1])

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line_lab = tk.Label(self, image=linerender)
        line_lab.pack()
        line_lab.image = linerender
        line_lab.place(x=dc.topHorzLinePos[0], y=dc.topHorzLinePos[1])

        ## --------------------------------------------------------------------------------------
        # Rest, Truck, Wifi, Date
        helv2 = font.Font(family='Helvetica', size=16, weight=font.BOLD)

        self.truckid_button = tk.Button(self, text='CHANGE TRUCK ID', fg='blue', width=22, height=2, font=helv2,
                                        command=self.change_TrauckID)
        self.truckid_button.place(x=dc.setupTruckIDButtonPos[0], y=dc.setupTruckIDButtonPos[1])
        self.reset_button = tk.Button(self, text='FACTORY RESET', fg='blue', width=22, height=2, font=helv2,
                                      command=self.reset_Setup)
        self.reset_button.place(x=dc.setupResetButtonPos[0], y=dc.setupResetButtonPos[1])

        self.wifi_button = tk.Button(self, text='WIFI CONFIG', fg='blue', width=22, height=2, font=helv2,
                                     command=self.wifiDialog)
        self.wifi_button.place(x=dc.setupWiFiButtonPos[0], y=dc.setupWiFiButtonPos[1])
        self.date_button = tk.Button(self, text='DATE & TIME', fg='blue', width=22, height=2, font=helv2, )
        self.date_button.place(x=dc.setupDateButtonPos[0], y=dc.setupDateButtonPos[1])

        self.smtp_button = tk.Button(self, text='EMAIL CONFIGURATION', fg='blue', width=22, height=2, font=helv2,
                                     command=self.smtpDialog)
        self.smtp_button.place(x=dc.setupSMTPButtonPos[0], y=dc.setupSMTPButtonPos[1])
        self.support_button = tk.Button(self, text='SUPPORT', fg='blue', width=22, height=2, font=helv2,command=self.supportDialog)
        self.support_button.place(x=dc.setupSupportButtonPos[0], y=dc.setupSupportButtonPos[1])

        ## ---------------------------------------------------------------------------

        lineload = Image.open("./img/line.jpg")
        linerender = ImageTk.PhotoImage(lineload)
        line2_lab = tk.Label(self, image=linerender)
        line2_lab.pack()
        line2_lab.image = linerender
        line2_lab.place(x=dc.bottomHorzLinePos[0], y=dc.bottomHorzLinePos[1])

        self.time_lab = tk.Label(self, text="4:40 PM", font='Helvetica 14 bold')
        self.time_lab.pack(pady=0, padx=0)
        self.time_lab.place(x=dc.timeLabPos[0], y=dc.timeLabPos[1])
        self.date_lab = tk.Label(self, text="Friday, January 12, 2019", font='Helvetica 14 bold')
        self.date_lab.pack(pady=0, padx=0)
        self.date_lab.place(x=dc.dateLabPos[0], y=dc.dateLabPos[1])

        self.wifi_lab['bg'] = BACKGROUNDCOLCODE
        truck_lab['bg'] = BACKGROUNDCOLCODE
        self.truckid_lab['bg'] = BACKGROUNDCOLCODE
        company_lab['bg'] = BACKGROUNDCOLCODE
        line_lab['bg'] = BACKGROUNDCOLCODE
        line2_lab['bg'] = BACKGROUNDCOLCODE
        self.time_lab['bg'] = BACKGROUNDCOLCODE
        self.date_lab['bg'] = BACKGROUNDCOLCODE
        home_button['bg'] = BACKGROUNDCOLCODE

        DateTimeThreadedTask(self).start()
        TruckIDThreadedTask(self).start()
        WifiThreadedTask(self).start()

    def supportDialog(self):
        messagebox.showinfo("Support", "Please call at: 1-800-268-7400")

    def smtpDialog(self):
        self.w = smtpDialogWindow(self.master)
        # self.b["state"] = "disabled"
        self.master.wait_window(self.w.top)
        # self.b["state"] = "normal"

        try:
            if self.w.smtpStat == True:
                smtp_server = self.w.smtp_server
                smtp_port = self.w.smtp_port
                smtp_email = self.w.smtp_email
                smtp_pwd = self.w.smtp_pwd
                smtp_ccemail = self.w.smtp_ccemail
                x = {"SERVER": smtp_server, "PORT": smtp_port, "EMAIL": smtp_email, "PASSWORD": smtp_pwd,
                     "CC": smtp_ccemail}
                y = json.dumps(x)
                new_file = open("./db/smtpconfig.dat", mode="wb")
                my_str_as_bytes = str.encode(y)
                new_file.write(my_str_as_bytes)
                new_file.close()
        except:
            print('WIFI CON ERROR')

    def reset_Setup(self):
        MsgBox = tk.messagebox.askquestion('Reset Application', 'Are you sure you want to reset the application',
                                           icon='warning')
        if MsgBox == 'yes':
            os.remove("./db/truckid.dat")

    def change_TrauckID(self):
        global hostnameedit
        self.wid = popupKeyBoardWindow("CHANGE TRUCK ID",'ENTER NEW TRUCK ID',0)
        self.master.wait_window(self.wid)
        #print(self.entryValue())
        try:
            if len(self.entryValue()) > 0:

                new_file = open("./db/truckid.dat", mode="wb")
                my_str = self.entryValue()
                truckid = 'WP-' + my_str
                my_str_as_bytes = str.encode(truckid)
                new_file.write(my_str_as_bytes)
                new_file.close()
                hostnameedit = False

                try:
                    subprocess.run(['sudo', '/home/pi/WeightRPI/change_hostname.sh', truckid])
                    # subprocess.call(['hostname', truckid])
                    MsgBox = tk.messagebox.askquestion('Reboot System', 'Sytem Reboot Required',
                                                       icon='warning')
                    if MsgBox == 'yes':
                        os.system('sudo shutdown -r now')
                except:
                    print('Hostname Edit Failed')

        except Exception as e:
            print('Truck ID FIle Error', e)

    def entryValue(self):
        try:
            keyval = self.wid.value
        except:
            keyval = ''
        finally:
            return keyval
        # if not self.wid.value:
        #    return ''
        # else:
        #    return self.wid.value

    def wifiDialog(self):

        global wifipath

        self.w = wifiDialogWindow(self.master)
        # self.b["state"] = "disabled"
        self.master.wait_window(self.w.top)
        # self.b["state"] = "normal"

        try:
            if self.w.wifistats == True:
                print('connecting to wifi', self.w.ssid,'---',self.w.pwd)

                if len(self.w.ssid) > 0 and len(self.w.pwd) > 0:
                    wireless.connect(ssid=self.w.ssid, password=self.w.pwd)
                elif len(self.w.ssid) > 0 and len(self.w.pwd) == 0:
                    wireless.connect(ssid=self.w.ssid)
                else:
                    print('NOT CONNECTING')
        except Exception as ex:
            print('WIFI CON ERROR:',ex)
        finally:
            try:
                # print(wireless.current())
                if (wireless.current() is not None):
                    wifipath = './img/wifi-online.png'
                else:
                    wifipath = './img/wifi.png'
                # print(wifipath)
            except Exception as ex:
                print('Wifi Status checking failed:',ex)


class wifiDialogWindow(object):
    def __init__(self, master):
        top = self.top = Toplevel(master)
        self.l = Label(top, text="CHOOSE ANY WIFI SSID")
        self.l.pack()
        self.wifistats = False
        self.mast = master
        # self.e=Entry(top)
        # self.e.pack()
        OPTIONS = self.getWIFIList()
        #OPTIONS = ('White', 'Grey', 'Black', 'Red', 'Orange','Yellow', 'Green', 'Blue', 'Cyan', 'Purple')
        self.e = StringVar(master)
        self.e.set(OPTIONS[0])  # default value
        w = OptionMenu(top, self.e, *OPTIONS)
        w.config(width=20, font='Helvetica 14 bold')
        menu = w.nametowidget(w.menuname)
        menu.configure(font=('Helvetica', 14))
        w.pack()

        self.l2 = Label(top, text="WIFI PASSWORD [IF REQUIRED]")
        self.l2.pack()
        self.e2 = Entry(top,show='*')
        self.e2.bind("<Button-1>", self.some_callback)
        self.e2.pack()
        self.b = Button(top, text='CONNECT WIFI', command=self.cleanup)
        self.b.pack()

    def cleanup(self):
        self.ssid = self.e.get()
        self.pwd = self.e2.get()
        self.wifistats = True
        self.top.destroy()

    def getWIFIList(self):
        try:

            scanoutput = check_output(["iwlist", "wlan0", "scan"])

            ssid = []

            for line in scanoutput.split():
                line = line.decode("utf-8")
                # print(line)
                # if line[:5]  == "ESSID":
                #  ssid = line.split('"')[1]
                if line.startswith("ESSID"):
                    eid = line.split('\"')[1]
                    if eid not in ssid:
                        ssid.append(eid)
            if len(ssid) < 1:
                os.system('sudo ifconfig wlan0 down')
                os.system('sudo ifconfig wlan0 up')
                time.sleep(1)
                scanoutput = check_output(["iwlist", "wlan0", "scan"])

                ssid = []

                for line in scanoutput.split():
                    line = line.decode("utf-8")
                    # print(line)
                    # if line[:5]  == "ESSID":
                    #  ssid = line.split('"')[1]
                    if line.startswith("ESSID"):
                        eid = line.split('\"')[1]
                        if eid not in ssid:
                            ssid.append(eid)

            return ssid
        except:
            return []

    def some_callback(self, event):  # note that you must include the event as an arg, even if you don't use it.
        self.wid = popupKeyBoardWindow("ENTER WIFI PASSWORD",'',0,0)
        self.mast.wait_window(self.wid)
        if not self.wid.value:
            return None
        else:
            self.e2.delete(0, tk.END)
            self.e2.insert(0, self.wid.value)
        return None


class smtpDialogWindow(object):
    def __init__(self, master):
        [self.smtp_server, self.smtp_port, self.smtp_email, self.smtp_pwd, self.smtp_ccemail] = self.getSMTPConfig()
        self.smtpStat = False
        self.mast = master
        large_font = ('Verdana', 14)
        helv2 = font.Font(family='Helvetica', size=14, weight=font.BOLD)
        top = self.top = Toplevel(master)
        self.l1 = Label(top, text="ENTER INFO:    SMTP SERVER", font='Helvetica 14 bold')
        self.l1.pack()
        self.e1 = Entry(top, font=large_font)
        self.e1.pack(ipady=3)

        self.l2 = Label(top, text="ENTER INFO:     SMTP  PORT", font='Helvetica 14 bold')
        self.l2.pack()
        self.e2 = Entry(top, font=large_font)
        self.e2.pack(ipady=3)

        self.l3 = Label(top, text="ENTER INFO:    YOUR  EMAIL", font='Helvetica 14 bold')
        self.l3.pack()
        self.e3 = Entry(top, font=large_font)
        self.e3.pack(ipady=3)

        self.l4 = Label(top, text="ENTER INFO: EMAIL PASSWORD", font='Helvetica 14 bold')
        self.l4.pack()
        self.e4 = Entry(top, font=large_font, show="*")
        self.e4.pack(ipady=3)

        self.l5 = Label(top, text="ENTER INFO:RECIPIENT EMAIL", font='Helvetica 14 bold')
        self.l5.pack()
        self.e5 = Entry(top, font=large_font)
        self.e5.pack(ipady=3)

        self.e1.delete(0, tk.END)
        self.e1.insert(0, self.smtp_server)
        self.e2.delete(0, tk.END)
        self.e2.insert(0, str(self.smtp_port))
        self.e3.delete(0, tk.END)
        self.e3.insert(0, self.smtp_email)
        self.e4.delete(0, tk.END)
        self.e4.insert(0, self.smtp_pwd)
        self.e5.delete(0, tk.END)
        self.e5.insert(0, self.smtp_ccemail)

        self.e1.bind("<Button-1>", self.some_callback_e1)
        self.e2.bind("<Button-1>", self.some_callback_e2)
        self.e3.bind("<Button-1>", self.some_callback_e3)
        self.e4.bind("<Button-1>", self.some_callback_e4)
        self.e5.bind("<Button-1>", self.some_callback_e5)

        self.b = Button(top, text='SAVE INFORMATION', fg='blue', width=20, font=helv2, command=self.cleanup)
        self.b.pack()

    def cleanup(self):
        try:
            self.smtp_server = self.e1.get()
            self.smtp_port = int(str(self.e2.get()))
            self.smtp_email = self.e3.get()
            self.smtp_pwd = self.e4.get()
            self.smtp_ccemail = self.e5.get()
            self.smtpStat = True
            self.top.destroy()
        except:
            print('Data Entry Error')

    def some_callback_e1(self, event):  # note that you must include the event as an arg, even if you don't use it.
        self.wid = popupKeyBoardWindow("ENTER SMTP SERVER INFORMATION",self.smtp_server,1)
        self.mast.wait_window(self.wid)
        if not self.wid.value:
            return None
        else:
            self.e1.delete(0, tk.END)
            self.e1.insert(0, self.wid.value)
            self.smtp_server = self.wid.value
        return None

    def some_callback_e2(self, event):  # note that you must include the event as an arg, even if you don't use it.
        self.wid = popupKeyBoardWindow("ENTER SMTP PORT INFORMATION", self.smtp_port,1)
        self.mast.wait_window(self.wid)
        if not self.wid.value:
            return None
        else:
            self.e2.delete(0, tk.END)
            self.e2.insert(0, self.wid.value)
            self.smtp_port = self.wid.value
        return None

    def some_callback_e3(self, event):  # note that you must include the event as an arg, even if you don't use it.
        self.wid = popupKeyBoardWindow("ENTER USER EMAIL",self.smtp_email,1)
        self.mast.wait_window(self.wid)
        if not self.wid.value:
            return None
        else:
            self.e3.delete(0, tk.END)
            self.e3.insert(0, self.wid.value)
            self.smtp_email= self.wid.value
        return None

    def some_callback_e4(self, event):  # note that you must include the event as an arg, even if you don't use it.
        self.wid = popupKeyBoardWindow("ENTER USER PASSWORD", self.smtp_pwd,1,0)
        self.mast.wait_window(self.wid)
        if not self.wid.value:
            return None
        else:
            self.e4.delete(0, tk.END)
            self.e4.insert(0, self.wid.value)
            self.smtp_pwd= self.wid.value
        return None

    def some_callback_e5(self, event):  # note that you must include the event as an arg, even if you don't use it.
        self.wid = popupKeyBoardWindow("ENTER RECIPIENT EMAIL",self.smtp_ccemail,1)
        self.mast.wait_window(self.wid)
        if not self.wid.value:
            return None
        else:
            self.e5.delete(0, tk.END)
            self.e5.insert(0, self.wid.value)
            self.smtp_ccemail= self.wid.value
        return None

    def getSMTPConfig(self):
        smtp_server = None
        smtp_port = None
        smtp_email = None
        smtp_pwd = None
        smtp_ccemail = None
        try:
            file = pathlib.Path("./db/smtpconfig.dat")
            if file.exists():
                new_file = open("./db/smtpconfig.dat", mode="rb")
                line = new_file.readline()
                new_file.close()
                if not line:
                    smtp_server = ''
                    smtp_port = ''
                    smtp_email = ''
                    smtp_pwd = ''
                    smtp_ccemail = ''
                else:
                    x = line.decode('UTF-8')
                    y = json.loads(x)
                    smtp_server = y["SERVER"]
                    smtp_port = y["PORT"]
                    smtp_email = y["EMAIL"]
                    smtp_pwd = y["PASSWORD"]
                    smtp_ccemail = y["CC"]

        except:
            smtp_server = ''
            smtp_port = ''
            smtp_email = ''
            smtp_pwd = ''
            smtp_ccemail = ''
        finally:
            return [smtp_server, smtp_port, smtp_email, smtp_pwd, smtp_ccemail]


class emailDialogWindow(object):
    def __init__(self, master):
        self.emailStat = False
        self.mast = master

        [smtp_server, smtp_port, smtp_email, smtp_pwd, self.smtp_ccemail] = self.getSMTPConfig()
        large_font = ('Verdana', 14)
        helv2 = font.Font(family='Helvetica', size=14, weight=font.BOLD)
        top = self.top = Toplevel(master)
        self.l1 = Label(top, text="Recipient Email Address", font='Helvetica 14 bold')
        self.l1.pack()
        entryText = tk.StringVar()
        entryText.set(self.smtp_ccemail)
        self.e1 = Entry(top, textvariable=entryText, font=large_font)
        self.e1.bind("<Button-1>", self.some_callback)
        self.e1.pack(ipady=3)
        self.b = Button(top, text='SEND EMAIL', fg='blue', width=20, font=helv2, command=self.cleanup)
        self.b.pack()

    def cleanup(self):
        try:
            self.emailid = self.e1.get()
            self.emailStat = True
            self.top.destroy()
        except:
            print('Email Sent Error')

    def getSMTPConfig(self):
        smtp_server = None
        smtp_port = None
        smtp_email = None
        smtp_pwd = None
        smtp_ccemail = None
        try:
            file = pathlib.Path("./db/smtpconfig.dat")
            if file.exists():
                new_file = open("./db/smtpconfig.dat", mode="rb")
                line = new_file.readline()
                new_file.close()
                if not line:
                    smtp_server = ''
                    smtp_port = ''
                    smtp_email = ''
                    smtp_pwd = ''
                    smtp_ccemail = ''
                else:
                    x = line.decode('UTF-8')
                    y = json.loads(x)
                    smtp_server = y["SERVER"]
                    smtp_port = y["PORT"]
                    smtp_email = y["EMAIL"]
                    smtp_pwd = y["PASSWORD"]
                    smtp_ccemail = y["CC"]

        except:
            smtp_server = ''
            smtp_port = ''
            smtp_email = ''
            smtp_pwd = ''
            smtp_ccemail = ''
        finally:
            return [smtp_server, smtp_port, smtp_email, smtp_pwd, smtp_ccemail]

    def some_callback(self, event):  # note that you must include the event as an arg, even if you don't use it.
        self.wid = popupKeyBoardWindow("UPDATE RECEIPIENT EMAIL",self.smtp_ccemail,1)
        self.mast.wait_window(self.wid)
        if not self.wid.value:
            return None
        else:
            self.e1.delete(0, tk.END)
            self.e1.insert(0, self.wid.value)
            self.smtp_ccemail = self.wid.value
        return None

class SingleLoadThreadedTask(threading.Thread):
    def __init__(self, window):
        threading.Thread.__init__(self)
        self.window = window
        self.oldWeight = '0'
        self.WCOUNT = 0
        self.WSTAT = False

    def run(self):
        #print('SingleLoadThreadedTask Running...')
        global running
        try:
            running = True
            self.rsserial = self.window.rsserial
            if self.rsserial.isOpen():
                try:
                    self.rsserial.flushInput()
                    self.rsserial.flushOutput()
                    time.sleep(0.2)
                    while running:
                        try:
                            response = self.rsserial.readline()
                            if len(response) > 5:
                                response = self.rsserial.readline().decode('UTF-8')
                                # response = self.rsserial.readline().decode('UTF-8')
                                #print("read data: " + response)
                                response = re.sub(r"[^a-zA-Z0-9]+", ' ', response)
                                response = response.strip()
                                #print("received data: " + response)
                                if len(response) > 0:
                                    currentWeight = self.extractDigit(response)
                                    if currentWeight != '-1':
                                        self.doProcessing(response, currentWeight)
                                    else:
                                        print('Weight coming Zero')
                            time.sleep(self.window.INTERVAL)
                            self.rsserial.flushInput()
                            self.rsserial.flushOutput()
                        except:
                            print('Main Inner Serial Error')
                            self.rsserial.flushInput()
                            self.rsserial.flushOutput()
                            time.sleep(0.1)
                except:
                    print('Main Inner Error')
                    self.window.showError()
            else:
                self.window.showDevError()
            ############ TESTING
            """
            while running:
                print('Waiting for data...')
                cval = random.randint(0, 1)
                rval = random.randint(5000, 10000) * 1.7
                if cval == 0:
                    response = str(rval) + ' LBS GR'
                else:
                    response = str(rval) + ' KG GR'
                weight = self.extractDigit(response)
                if weight != '-1':
                    self.doProcessing(response, weight)
                #time.sleep(self.window.INTERVAL)
                time.sleep(10)
            """

        except:
            running = False
            print('Main Outer Error')
            self.window.showError()
        finally:
            if self.rsserial.isOpen():
                try:
                    self.rsserial.close()
                except:
                    print('Close Serial Error')
        print('Single Loop Run Finished')

    def extractDigit(self, response):
        try:
            value = (float)(re.findall(r"[-+]?\d*\.\d+|\d+", response)[0])
            #print(response)
            value = "{0:.4f}".format(value)
            value = self.dropzeros(value)
        except:
            value = -1
            print('Weight conversion error')
        finally:
            return str(value)

    def dropzeros(self, number):
        mynum = decimal.Decimal(number).normalize()
        return mynum.__trunc__() if not mynum % 1 else float(mynum)

    def doProcessing(self, response, weight):
        global singleBarCode, oldBarCode, activeTruckID
        try:
            if 'M' not in response and weight != self.oldWeight:
                self.WCOUNT = 0
                self.oldWeight = weight
                self.WCOUNT = self.WCOUNT+1
                self.WSTAT = True
            elif 'M' not in response and weight == self.oldWeight:
                if self.WCOUNT >= self.window.WEIGHTCHECKING and self.WSTAT==True:
                    #print('Displaying Barcode Now: ',weight)
                    self.WSTAT = False
                    self.WCOUNT = 0
                    now = datetime.now()
                    date_time = now.strftime("%m/%d/%Y %H:%M:%S")
                    meas = response.split()[1]
                    self.oldWeight = weight
                    EAN = barcode.get_barcode_class('code128')
                    ean = EAN(weight, writer=ImageWriter())
                    fullname = ean.save('./img/barcode')
                    self.window.updateImage(meas)
                    if singleBarCode != None:
                        self.window.changeProcStatus("DATA SAVED WITH B/L. SCAN NEW")
                    else:
                        self.window.changeProcStatus("DATA SAVED WITHOUT B/L. SCAN NEW")

                    if singleBarCode != None:
                        scancode = singleBarCode
                    elif singleBarCode == 'ERROR':
                        scancode = 'NO DATA'
                    else:
                        scancode = 'NO DATA'

                    self.insertData([activeTruckID, weight, meas, scancode, 'SINGLE', date_time])
                    oldBarCode = singleBarCode
                    singleBarCode = None

                    self.window.changeBLCodeStatus('SCAN FIRST')
                    # self.window.blcode_lab['text'] = 'SCAN AGAIN'
                    # time.sleep(1)
                    # self.window.changeProcStatusStart()
                else:
                    self.WCOUNT = self.WCOUNT+1
            else:
                print('Response contains M')

        except:
            print('Data Decoding Error')

    def insertData(self, data):
        #print('Storing into DB')
        try:
            conn = sqlite3.connect('./db/weightrpi.db')
            sql = 'INSERT INTO tbl_weight_info(truckid,weight,measurement,barcode, scantype,recorded) VALUES (?,?,?,?,?,?)'
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
        except Error as e:
            print(e)
        finally:
            conn.close()

        chw = float(data[1])
        meas = str(data[2])
        if meas == 'KG':
            chw = chw * 2.20462
        if chw > 5000.0:
            try:
                conn = sqlite3.connect('./db/weightfiverpi.db')
                sql = 'INSERT INTO tbl_weight_five_info(truckid,weight,measurement,barcode, scantype,recorded) VALUES (?,?,?,?,?,?)'
                cur = conn.cursor()
                cur.execute(sql, data)
                conn.commit()
            except Error as e:
                print(e)
            finally:
                conn.close()


class CombinedLoadThreadedTask(threading.Thread):
    def __init__(self, window):
        threading.Thread.__init__(self)
        self.window = window
        self.oldWeight = '0'
        self.WCOUNT = 0
        self.WSTAT = False

    def run(self):
        global running, combinedWeight
        try:
            running = True
            self.rsserial = self.window.rsserial
            if self.rsserial.isOpen():
                try:
                    self.rsserial.flushInput()
                    self.rsserial.flushOutput()
                    time.sleep(0.2)
                    while running:
                        try:
                            response = self.rsserial.readline()
                            if len(response) > 5:
                                response = self.rsserial.readline().decode('UTF-8')
                                # response = self.rsserial.readline().decode('UTF-8')
                                # print("read data: " + response)
                                response = re.sub(r"[^a-zA-Z0-9]+", ' ', response)
                                response = response.strip()
                                #print("received data: " + response)
                                if len(response) > 0:
                                    currentWeight = self.extractDigit(response)
                                    if currentWeight != '-1':
                                        combinedWeight = (float)(currentWeight)
                                        self.doProcessing(response, currentWeight)
                                    else:
                                        print('Weight coming Zero')
                            time.sleep(self.window.INTERVAL)
                            self.rsserial.flushInput()
                            self.rsserial.flushOutput()
                        except:
                            print('Main Inner Serial Error')
                            self.rsserial.flushInput()
                            self.rsserial.flushOutput()
                            time.sleep(0.1)

                except:
                    print('Main Inner Error')
                    self.window.showError()
            else:
                self.window.showDevError()
                ############ TESTING
                """
                while running:
                    print('Waiting for data...')
                    cval = random.randint(0, 1)
                    rval = random.randint(10, 100) * 1.7
                    if cval == 0:
                        response = str(rval) + ' LBS GR'
                    else:
                        response = str(rval) + ' KG GR'
                    weight = self.extractDigit(response)
                    if weight != '-1':
                        self.doProcessing(response, weight)
                    time.sleep(self.window.INTERVAL)
                """

        except:
            running = False
            print('Main Outer Error')
            self.window.showError()
        finally:
            if self.rsserial.isOpen():
                try:
                    self.rsserial.close()
                except:
                    print('Close Serial Error')
        print('Combine Loop Run Finished')

    def extractDigit(self, response):
        try:
            value = (float)(re.findall(r"[-+]?\d*\.\d+|\d+", response)[0])
            print(response)
            value = "{0:.4f}".format(value)
            value = self.dropzeros(value)
        except:
            value = -1
            print('Weight conversion error')
        finally:
            return str(value)

    def dropzeros(self, number):
        mynum = decimal.Decimal(number).normalize()
        return mynum.__trunc__() if not mynum % 1 else float(mynum)

    def doProcessing(self, response, weight):
        try:
            #print('RESPONSE:', response)
            #print('WEIGHT:',weight)
            if 'M' not in response and weight != self.oldWeight:
                self.WCOUNT = 0
                self.oldWeight = weight
                self.WCOUNT = self.WCOUNT + 1
                self.WSTAT = True
            elif 'M' not in response and weight == self.oldWeight:
                if self.WCOUNT >= self.window.WEIGHTCHECKING and self.WSTAT == True:
                    self.WSTAT = False
                    self.WCOUNT = 0
                    now = datetime.now()
                    date_time = now.strftime("%m/%d/%Y %H:%M:%S")
                    meas = response.split()[1]
                    self.oldWeight = weight
                    EAN = barcode.get_barcode_class('code128')
                    #from barcode.writer import ImageWriter
                    ean = EAN(weight, writer=ImageWriter())
                    fullname = ean.save('./img/barcode')
                    self.window.updateImage(meas)

                    global combinedBarCode, activeTruckID
                    #if combinedBarCode != None:
                    #    self.window.changeProcStatusWeight(1)
                    #else:
                    #    self.window.changeProcStatusWeight(2)
                    if combinedBarCode != None:
                        scancode = combinedBarCode
                    elif combinedBarCode == 'ERROR':
                        scancode = 'NO DATA'
                    else:
                        scancode = 'NO DATA'

                    self.insertData([activeTruckID, weight, meas, scancode, 'COMBINE1', date_time])
                else:
                    self.WCOUNT = self.WCOUNT+1

            else:
                print('Response contains M')

        except:
            print('Data Decoding Error')

    def insertData(self, data):
        #print('Storing into DB')
        try:
            conn = sqlite3.connect('./db/weightrpi.db')
            sql = 'INSERT INTO tbl_weight_info(truckid, weight,measurement,barcode, scantype,recorded) VALUES (?,?,?,?,?,?)'
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
        except Error as e:
            print(e)
        finally:
            conn.close()
        chw = float(data[1])
        meas = str(data[2])
        if meas == 'KG':
            chw = chw * 2.20462
        if chw > 5000.0:
            try:
                conn = sqlite3.connect('./db/weightfiverpi.db')
                sql = 'INSERT INTO tbl_weight_five_info(truckid,weight,measurement,barcode, scantype,recorded) VALUES (?,?,?,?,?,?)'
                cur = conn.cursor()
                cur.execute(sql, data)
                conn.commit()
            except Error as e:
                print(e)
            finally:
                conn.close()


class DateTimeThreadedTask(threading.Thread):
    def __init__(self, window):
        threading.Thread.__init__(self)
        self.window = window

    def run(self):
        global trunning
        # time.sleep(1)
        #print(trunning)
        while trunning:
            now = datetime.now()
            currentTime = now.strftime("%H:%M %p")
            currentDate = now.strftime("%A, %B %d, %Y")
            self.window.time_lab["text"] = (currentTime)
            self.window.date_lab["text"] = (currentDate)
            time.sleep(1)


class TruckIDThreadedTask(threading.Thread):
    def __init__(self, window):
        threading.Thread.__init__(self)
        self.window = window

    def run(self):
        global trunning, activeTruckID, hostnameedit
        while trunning:
            try:
                if os.path.exists('./db/truckid.dat'):
                    new_file = open("./db/truckid.dat", mode="rb")
                    line = new_file.readline()
                    new_file.close()
                    if not line:
                        continue
                    else:
                        truckid = line.decode('UTF-8')
                        self.window.truckid_lab["text"] = (truckid)
                        activeTruckID = truckid
                        if hostnameedit == True:
                            try:
                                subprocess.run(['sudo', '/home/pi/WeightRPI/change_hostname.sh', truckid])
                                #subprocess.call(['hostname', truckid])
                            except:
                                print('Hostname Edit Failed')
                            finally:
                                hostnameedit = False


                else:
                    self.window.truckid_lab["text"] = 'NULL'
            except:
                print('Truck ID FIle error')
            time.sleep(1)

"""
class WifiThreadedTask(threading.Thread):
    def __init__(self, window):
        threading.Thread.__init__(self)
        self.window = window
        self.conter = 0
    def run(self):
        global wrunning, wifipath, oldwifipath
        # print(wifipath)
        while wrunning:
            try:
                if oldwifipath != None:
                    if wifipath != oldwifipath:
                        wifiload = Image.open(wifipath)
                        wifirender = ImageTk.PhotoImage(wifiload)
                        # self.window.wifi_lab = Label(self, image=wifirender)
                        self.window.wifi_lab["image"] = wifirender
                        self.window.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])
                        oldwifipath = wifipath
                    else:
                        self.conter = self.conter+1
                        if self.conter>100:
                            self.conter = 0
                            try:
                                if (wireless.current() is not None):
                                    wifipath = './img/wifi-online.png'
                                else:
                                    wifipath = './img/wifi.png'
                                # print(wifipath)
                            except:
                                print('Wifi Status checking failed')
                            finally:
                                wifiload = Image.open(wifipath)
                                wifirender = ImageTk.PhotoImage(wifiload)
                                # self.window.wifi_lab = Label(self, image=wifirender)
                                self.window.wifi_lab["image"] = wifirender
                                self.window.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])
                                oldwifipath = wifipath
                else:
                    oldwifipath = wifipath
                    wifiload = Image.open(wifipath)
                    wifirender = ImageTk.PhotoImage(wifiload)
                    # self.window.wifi_lab = Label(self, image=wifirender)
                    self.window.wifi_lab["image"] = wifirender
                    self.window.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])

            except:
                wifiload = Image.open("./img/wifi.png")
                wifirender = ImageTk.PhotoImage(wifiload)
                # self.window.wifi_lab = Label(self, image=wifirender)
                self.window.wifi_lab["image"] = wifirender
                self.window.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])

            time.sleep(1)
"""

class WifiThreadedTask(threading.Thread):
    def __init__(self, window):
        threading.Thread.__init__(self)
        self.window = window

    def run(self):
        global wrunning, wifipath, oldwifipath
        # print(wifipath)
        while wrunning:
            try:
                if oldwifipath != None:
                    if wifipath != oldwifipath:
                        wifiload = Image.open(wifipath)
                        wifirender = ImageTk.PhotoImage(wifiload)
                        # self.window.wifi_lab = Label(self, image=wifirender)
                        self.window.wifi_lab["image"] = wifirender
                        self.window.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])
                else:
                    oldwifipath = wifipath
                    wifiload = Image.open(wifipath)
                    wifirender = ImageTk.PhotoImage(wifiload)
                    # self.window.wifi_lab = Label(self, image=wifirender)
                    self.window.wifi_lab["image"] = wifirender
                    self.window.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])
            except:
                wifiload = Image.open("./img/wifi.jpg")
                wifirender = ImageTk.PhotoImage(wifiload)
                # self.window.wifi_lab = Label(self, image=wifirender)
                self.window.wifi_lab["image"] = wifirender
                self.window.wifi_lab.place(x=dc.wifiImagePos[0], y=dc.wifiImagePos[1])
            time.sleep(1)


class CloseMessageWindow(tk.Toplevel):
    def __init__(self, title, message):
        super().__init__()
        self.details_expanded = False
        self.title(title)
        self.geometry("800x75+{}+{}".format(self.master.winfo_x(), self.master.winfo_y()))
        self.resizable(False, False)
        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)
        self.columnconfigure(0, weight=1)
        self.columnconfigure(1, weight=1)
        tk.Label(self, text=message).grid(row=0, column=0, columnspan=3, pady=(7, 7), padx=(7, 7), sticky="ew")
        tk.Button(self, text="CLOSE APPLICATION", command=self.master.destroy).grid(row=1, column=1, padx=(7, 7),
                                                                                    sticky="e")
        # tk.Button(self, text="Cancel", command=self.destroy).grid(row=1, column=2, padx=(7, 7), sticky="e")


buttons = [
    '~','!','@', '#', '$', '%', '&', '*', '(', ')', '-', '_', '=',
    'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '\\','{','}',
    'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', '[', ']', 'SPACE',
    'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', '<', 'SHIFT',
    '>', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'BACK'
]

global shiftkey
shiftkey = True

def select(value, entry):
    global shiftkey,shiftB
    if value == "BACK":
        # allText = entry.get()[:-1]
        # entry.delete(0, tkinter,END)
        # entry.insert(0,allText)

        entry.delete(len(entry.get()) - 1, tkinter.END)
    elif value == "SHIFT":
        # entry.insert(tkinter.END, value.lower())
        if shiftkey == True:
            shiftkey = False
            shiftB['bg'] = 'green'
        else:
            shiftkey = True
            shiftB['bg'] = '#3c4987'

    elif value == "SPACE":
        entry.insert(tkinter.END, ' ')
    elif value == " Tab ":
        entry.insert(tkinter.END, '    ')
    else:
        if shiftkey == True:
            value = value.upper()
        else:
            value = value.lower()
        entry.insert(tkinter.END, value)

def HosoPop(self, entry, ch=0):
    global shiftB
    varRow = 2
    varColumn = 0
    if ch == 0:
        entry.delete(0, tkinter.END)
    helv2 = font.Font(family='Helvetica', size=11, weight=font.BOLD)
    for button in buttons:

        command = lambda x=button: select(x, entry)

        if button == "SPACE" or button == "SHIFT" or button == "BACK":
            b = tkinter.Button(self, text=button, width=12,height=4, bg="#3c4987", fg="#ffffff", font=helv2,
                           activebackground="#ffffff", activeforeground="#3c4987", relief='raised', padx=1,
                           pady=1, bd=1, command=command)
            b.grid(row=varRow, column=varColumn)
            if button == 'SHIFT':
                shiftB = b

        else:
            tkinter.Button(self, text=button, width=6,height=4, bg="#3c4987", fg="#ffffff",font=helv2,
                           activebackground="#ffffff", activeforeground="#3c4987", relief='raised', padx=1,
                           pady=1, bd=1, command=command).grid(row=varRow, column=varColumn)

        varColumn += 1

        if varColumn > 12 and varRow == 2:
            varColumn = 0
            varRow += 1
        if varColumn > 12 and varRow == 3:
            varColumn = 0
            varRow += 1
        if varColumn > 11 and varRow == 4:
            varColumn = 0
            varRow += 1
        if varColumn > 11 and varRow == 5:
            varColumn = 0
            varRow += 1

class popupKeyBoardWindow(tk.Toplevel):
    def __init__(self, title,msg,ch=0,ps=0):
        super().__init__()
        self.value = None
        # self.top = Toplevel(self)
        self.details_expanded = False
        self.title(title)
        self.geometry("800x480+{}+{}".format(self.master.winfo_x(), self.master.winfo_y()))
        self.resizable(False, False)

        #self.overrideredirect(True)
        #self.wait_visibility(self)
        self.wm_attributes('-alpha', 0.95)
        self.attributes("-fullscreen", True)

        large_font = ('Verdana', 14)
        if ps==0:
            self.entry = Entry(self, font=large_font)
        else:
            self.entry = Entry(self, font=large_font,show='*')
        self.entry.delete(0, tkinter.END)
        self.entry.insert(0, msg)
        # self.entry.place(x=100,y=0)
        self.entry.grid(row=1, columnspan=11)
        HosoPop(self, self.entry, ch)
        #self.entry.bind("<Button-1>", lambda e: HosoPop(self, self.entry,1))
        sbut = tk.Button(self, text="SAVE ENTRY", command=self.cleanup)
        sbut.place(x=12, y=432)
        sclose = tk.Button(self, text="CLOSE KEYBOARD", command=self.destroy)
        sclose.place(x=200, y=432)

    def cleanup(self):
        self.value = self.entry.get()
        self.destroy()



if __name__ == "__main__":
    if not os.path.exists('./db/truckid.dat'):
        from KeyBoard import HosKeyboard
        keyb = HosKeyboard()
        keyb.initKey()
        #print(keyb.truckid)
        if len(keyb.truckid) > 0:
            try:
                new_file = open("./db/truckid.dat", mode="wb")
                my_str = keyb.truckid
                truckid = 'WP-' + my_str
                my_str_as_bytes = str.encode(truckid)
                new_file.write(my_str_as_bytes)
                new_file.close()
                subprocess.run(['sudo', '/home/pi/WeightRPI/change_hostname.sh', truckid])
                # subprocess.call(['hostname', truckid])
                print('Rebooting')
                os.system('sudo shutdown -r now')

            except Exception as e:
                print('Truck ID FIle Error', e)

    else:

        app = MainAppWindow()
        app.mainloop()

