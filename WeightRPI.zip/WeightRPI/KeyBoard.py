from tkinter import *
import tkinter

class HosKeyboard():
    def __init__(self):
        self.kb = tkinter.Tk()
        # 'BACK','SHIFT','SPACE',
        self.buttons = [
            '~','!','@', '#', '$', '%', '&', '*', '(', ')', '-', '_', '=',
            'Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P', '\\','{','}',
            'A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L', '[', ']', 'SPACE',
            'Z', 'X', 'C', 'V', 'B', 'N', 'M', ',', '.', '/', '<', 'SHIFT',
            '>', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'BACK'
        ]

        global shiftkey
        shiftkey =  True
        self.truckid = ''

    def select(self,value,entry):
        global shiftkey

        if value == "BACK":
            # allText = entry.get()[:-1]
            # entry.delete(0, tkinter,END)
            # entry.insert(0,allText)

            entry.delete(len(entry.get()) - 1, tkinter.END)
        elif value == "SHIFT":
            #entry.insert(tkinter.END, value.lower())
            if shiftkey == True:
                shiftkey=False
                self.shiftB['bg']='green'
            else:
                shiftkey = True
                self.shiftB['bg'] = '#3c4987'
                #self.shiftB['activebackground'] = "#ffffff"
                #self.shiftB['activeforeground']= "#3c4987"
                #self.shiftB['activeforeground'] = "#3c4987"

        elif value == "SPACE":
            entry.insert(tkinter.END, ' ')
        elif value == " Tab ":
            entry.insert(tkinter.END, '    ')
        else:
            if shiftkey==True:
                value = value.upper()
            else:
                value = value.lower()
            entry.insert(tkinter.END, value)

        self.truckid = entry.get()

    def HosoPop(self,entry):
        varRow = 2
        varColumn = 0
        entry.delete(0, tkinter.END)
        helv2 = font.Font(family='Helvetica', size=11, weight=font.BOLD)
        for button in self.buttons:

            command = lambda x=button: self.select(x,entry)

            if button == "SPACE" or button == "SHIFT" or button == "BACK":
                b = tkinter.Button(self.kb, text=button, width=12,height=3, bg="#3c4987", fg="#ffffff",font=helv2,
                                   activebackground="#ffffff", activeforeground="#3c4987", relief='raised', padx=1,
                                   pady=1, bd=1, command=command)
                b.grid(row=varRow, column=varColumn)
                if button == 'SHIFT':
                    self.shiftB = b


            else:
                #print(button,varRow,varColumn)
                tkinter.Button(self.kb, text=button, width=6,height=3, bg="#3c4987", fg="#ffffff",font=helv2,
                               activebackground="#ffffff", activeforeground="#3c4987", relief='raised', padx=1,
                               pady=1, bd=1, command=command).grid(row=varRow, column=varColumn)

            varColumn += 1

            if varColumn > 12 and varRow == 2:
                varColumn = 0
                varRow += 1
            if varColumn > 12 and varRow == 3:
                varColumn = 0
                varRow += 1
            if varColumn > 11 and varRow == 4:
                varColumn = 0
                varRow += 1
            if varColumn > 11 and varRow == 5:
                varColumn = 0
                varRow += 1
    def cleanup(self,entry):
        self.truckid = entry.get()
        self.kb.quit()

    def initKey(self):
        large_font = ('Verdana', 14)
        self.kb.title("ACTION REQUIRED::NO TRUCK ID FOUND!!!")
        self.kb.resizable(0, 0)
        self.kb.geometry('800x420')

        #self.label1 = Label(self.kb, text='Please enter new Truck ID').grid(row=0, columnspan=11)

        #global entry
        entry = Entry(self.kb, font=large_font)
        entry.grid(row=1, columnspan=11)
        #entry.pack()

        entry.delete(0, tkinter.END)
        entry.insert(0, 'CLICK HERE FOR ENTRY')

        entry.bind("<Button-1>", lambda e: self.HosoPop(entry))
        truckid_button = Button(self.kb, text='CHANGE TRUCK ID', fg='blue', width=20, height=2,command=self.kb.destroy)
        truckid_button.place(x=10,y=360)
        #sclose = Button(self, text="CLOSE KEYBOARD", command=self.kb.destroy)
        #sclose.place(x=100, y=440)

        #self.kb.attributes("-fullscreen", True)
        self.kb.mainloop()


