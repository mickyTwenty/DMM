import tkinter
from tkinter import font


class DesignConfig:
    def __init__(self):
        self.backgroundFullImagePos = [0, 0]
        self.wifiImagePos = [5, 5]
        self.activeTruckLabPos = [100, 18]
        self.activeTruckIDPos = [100, 50]
        self.homeButtonPos = [270, 22]
        self.companyLogoPos = [510, 22]
        self.topHorzLinePos = [0, 95]
        self.bottomHorzLinePos = [0, 430]
        self.timeLabPos = [5, 440]
        self.dateLabPos = [530, 440]

        self.homeSingleButtonPos = [8, 152]
        self.homeCombinedButtonPos = [208, 152]
        self.homeReportsButtonPos = [408, 152]
        self.homeSetupButtonPos = [608, 152]

        self.singleBarImagePos = [0, 105]
        self.singleBLLabPos = [485, 110]
        self.singleBLStatusLabPos = [485, 110]
        self.singleBLCodeLabPos = [500, 150]
        self.singleUndoButtonPos = [515, 200]
        self.singleBLScanButtonPos = [515, 270]
        self.singleBLKeyboardButtonPos = [515, 340]

        self.doubleBarImagePos = [0, 105]
        self.doubleBLLabPos = [485, 105]
        self.doubleBLStatusLabPos = [485, 105]
        self.doubleBLCodeLabPos = [500, 140]
        self.doubleUndoButtonPos = [490, 180]
        self.doubleBLScanButtonPos = [590, 180]
        self.doubleBLKeyboardButtonPos = [690, 180]
        self.doubleStartButtonPos = [515, 240]
        self.doubleNextButtonPos = [515, 300]
        self.doubleFinishButtonPos = [515, 370]

        self.reportEmailCSVButtonPos = [90, 150]
        self.reportEmailHTMLButtonPos = [400, 150]
        self.reportExportCSVButtonPos = [90, 300]
        self.reportExportAllButtonPos = [400, 300]

        self.setupTruckIDButtonPos = [90, 140]
        self.setupResetButtonPos = [400, 140]
        self.setupWiFiButtonPos = [90, 240]
        self.setupDateButtonPos = [400, 240]
        self.setupSMTPButtonPos = [90, 340]
        self.setupSupportButtonPos = [400, 340]

